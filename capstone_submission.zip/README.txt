The project is created with Jupyter Notebook.
Most of the data cleaning and exploratory analysis, model training and validation is done with Numpy, Pandas and Sklearn library.
You also need to install xgboost for model training by below commend.
!pip install xgboost